export { default as ContactInfo } from "./FaqsList";

export { default as PersonalDetails } from "./PortifolioList";

export { default as Hero } from "./Hero";
export { default as Filters } from "./Filters";
export { default as GetInTouch } from "./GetInTouch";
export { default as Testimonial } from "./Testimonial";

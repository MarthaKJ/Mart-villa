export { default as PropertyList } from "./property-4/PropertyList";

const SingleBlogPostCard = () => {
  return <div>SingleBlogPostCard</div>;
};

export default SingleBlogPostCard;
